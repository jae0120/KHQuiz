package com.example.android.khquiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    RadioGroup answerGroup1 = findViewById(R.id.q1_radio_group);
    RadioGroup answerGroup2 = findViewById(R.id.q2_radio_group);
    CheckBox AnswerOne = (CheckBox) findViewById(R.id.q3a1);
    CheckBox AnswerTwo = (CheckBox) findViewById(R.id.q3a2);
    CheckBox AnswerThree = (CheckBox) findViewById(R.id.q3a3);
    CheckBox AnswerFour = (CheckBox) findViewById(R.id.q3a4);
    CheckBox AnswerFive = (CheckBox) findViewById(R.id.q3a5);
    CheckBox AnswerSix = (CheckBox) findViewById(R.id.q3a6);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    int score;
/*
    // method to check q1
    public void checkq1() {
        int selectedId = answerGroup1.getCheckedRadioButtonId();
        radioAnswer1Button = (RadioButton) findViewById(selectedId);
        if (radioAnswer1Button.getText() == "2002") {
            score++;
        }
    }
    // method to check q2
    public void checkQ2() {
        int selectedId = answerGroup2.getCheckedRadioButtonId();
        radioAnswer2Button = (RadioButton) findViewById(selectedId);
        if (radioAnswer2Button.getText() == "Deep Jungle") {
            score++;
        }
    }

*/


    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.q1a1:
                if (checked)
                    break;
            case R.id.q1a2:
                if (checked)
                    //correct answer
                    score++;
                else {
                    score--;
                    answerGroup1.clearCheck();
                }
                break;
            case R.id.q1a3:
                if (checked)
                    break;
            case R.id.q1a4:
                if (checked)
                    break;


        }

    }

    public void onRadioButton2Clicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.q2a1:
                if (checked)
                    break;
            case R.id.q2a2:
                if (checked)
                    break;
            case R.id.q2a3:
                if (checked)
                    //correct answer
                    score++;
                else {
                    score--;
                    answerGroup1.clearCheck();
                }
                break;
            case R.id.q2a4:
                if (checked)
                    break;


        }

    }

    //method to check the checkbox question

    public void checkQ3() {
        Boolean Q3A1 = AnswerOne.isChecked();
        Boolean Q3A2 = AnswerTwo.isChecked();
        Boolean Q3A3 = AnswerThree.isChecked();
        Boolean Q3A4 = AnswerFour.isChecked();
        Boolean Q3A5 = AnswerFive.isChecked();
        Boolean Q3A6 = AnswerSix.isChecked();
        if (Q3A1 && Q3A2 && Q3A3 && Q3A4 && !Q3A5 && !Q3A6) {
            score++;
        }
    }

    // Method to check the edittext question

    public void checkQ4() {
        EditText q4Answer = (EditText) findViewById(R.id.q4_edit_text);
        String guestAnswer = q4Answer.getText().toString();
        Log.v("MainActivity", guestAnswer);
        if ((guestAnswer == "Xion") //|| (guestAnswer == "Shion") || (guestAnswer == "Xion.") || (guestAnswer == "Xion ")
                ) {
            score++;
        }
    }

    //displays the results
    private void displayScore(String results) {
        TextView scoreText = (TextView) findViewById(R.id.results_text_view);
        String checkText = (String) scoreText.getText();
        if (checkText.isEmpty())
            scoreText.setText(results);

    }

    //submitScore button
    public void submitScore(View view) {
        checkQ3();
        checkQ4();
        displayScore("You got " + score + " correct!");
    }

    //reset scores
    public void resetScores(View view) {
        TextView scoreText = (TextView) findViewById(R.id.results_text_view);
        scoreText.setText("");
        score = 0;
        answerGroup1.clearCheck();
        answerGroup2.clearCheck();
        if (AnswerOne.isChecked()) AnswerOne.toggle();
        if (AnswerTwo.isChecked()) AnswerTwo.toggle();
        if (AnswerThree.isChecked()) AnswerThree.toggle();
        if (AnswerFour.isChecked()) AnswerFour.toggle();
        if (AnswerFive.isChecked()) AnswerFive.toggle();
        if (AnswerSix.isChecked()) AnswerSix.toggle();
    }
}
